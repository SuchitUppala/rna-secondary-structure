var files_dup =
[
    [ "main (1).cpp", "main_01_071_08_8cpp.html", "main_01_071_08_8cpp" ],
    [ "RNAMolecule.h", "_r_n_a_molecule_8h.html", [
      [ "RNAMolecule", "class_r_n_a_molecule.html", "class_r_n_a_molecule" ]
    ] ]
];