var searchData=
[
  ['getbasepairs_0',['getBasePairs',['../class_r_n_a_molecule.html#aae783b3bba62435f10602700e0882123',1,'RNAMolecule']]]
];
